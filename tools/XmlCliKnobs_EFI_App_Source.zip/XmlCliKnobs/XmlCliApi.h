/** @file
  Definitions for XmlCliCommon

@copyright
 Copyright (c) 2015 - 2017 Intel Corporation. All rights reserved
 This software and associated documentation (if any) is furnished
 under a license and may only be used or copied in accordance
 with the terms of the license. Except as permitted by the
 license, no part of this software or documentation may be
 reproduced, stored in a retrieval system, or transmitted in any
 form or by any means without the express written consent of
 Intel Corporation.
 This file contains a 'Sample Driver' and is licensed as such
 under the terms of your license agreement with Intel or your
 vendor. This file may be modified by the user, subject to
 the additional terms of the license agreement.

@par Specification Reference:

**/

#ifndef _XML_CLI_API_H
#define _XML_CLI_API_H

#include "SharedMailbox.h"

#define PAGE_ALIGNMENT_64_BIT           0xFFFFFFFFFFFFF000
#define PAGE_ALIGNMENT_32_BIT           0xFFFFF000
#define ALIGNMENT_64_KB_32_BIT          0xFFFF0000

#define XML_LZMA_ONLY                   1
#define XML_TIANO_ONLY                  0
#define XML_LZMA_AND_TIANO              2

#define MAX_CLI_APIs_SUPPORTED          0x20  // 32

#define CLI_SGN_RESPONCE_READY          0xCAFECAFE
#define CLI_SGN_REQUEST_READY           0xC001C001
#define CLI_SGN_RESPONCE_GET            0xCAFE0001

#define CLI_MERLINX_SGN_RESPONCE_READY  0xD055CAFE
#define CLI_MERLINX_SGN_REQUEST_READY   0xD055C001
#define CLI_MERLINX_SGN_RESPONCE_GET    0xD0550001

// Command side effects
#define CLI_CMD_NO_SIDE_EFFECT          0
#define CLI_CMD_RESET_REQUIRED          1
#define CLI_CMD_RESTART_REQUIRED        2
#define CLI_CMD_SIDE_EFFECT_RESERVED    3

#define APPEND_BIOS_KNOBS_OPCODE        0x0048
#define RESTOREMODIFY_KNOBS_OPCODE      0x0049
#define READ_BIOS_KNOBS_OPCODE          0x004A
#define LOAD_DEFAULT_KNOBS_OPCODE       0x004B
#define UPDATE_BIOS_KNOBS_OPCODE        0x0050

#define EXIT_OPCODE                     0xFFFF

#define SW_XML_CLI_ENTRY                0xF6
#define SW_SMI_PORT                     0xB2

// XMLCLI:RestrictedBegin
#define SKIP_AUTHENTICATE_XML_CLI_API   1
// XMLCLI:RestrictedEnd

extern  EFI_GUID gXmlCliCommonGuid;

#pragma pack(push, 1)

typedef  EFI_STATUS (*DXE_CLI_ENTRY)(VOID *XmlCliCom);
typedef  EFI_STATUS (*ClicmdHandlerFunc)(VOID *Buffer);

typedef struct {
  UINT16             commandID;
  ClicmdHandlerFunc  cmdHandler;
  VOID               *Buffer;
} REG_CLI_COMMAND_ENTRY;

typedef  VOID  (*DXE_REG_CLI_API)(UINT16 commandID, ClicmdHandlerFunc ClicmdHandler, VOID *Buffer);
typedef  VOID  (*SMM_REG_CLI_API)(UINT16 commandID, ClicmdHandlerFunc ClicmdHandler, VOID *Buffer);

// BIOS Repository Data structure
typedef struct _XML_CLI_API
{
  DXE_CLI_ENTRY         DxeCliEntry;
  DXE_REG_CLI_API       DxeRegisterCliApi;
  SMM_REG_CLI_API       SmmRegisterCliApi;
// Please dont touch or change the above order of the entries in this Struct.
} XML_CLI_API;

typedef union {
  UINT16  rawAccess;
  struct {
    UINT16    wrongParameter      :1;
    UINT16    CannotExecute       :1;
    UINT16    commandSideEffects  :4;
    UINT16    Reserved            :10;
  } fields;
} CLI_BUFFER_FLAGS;

typedef struct {
  UINT32              signature;
  UINT16              commandID;
  CLI_BUFFER_FLAGS    flags;
  UINT32              status;
  UINT32              parametersSize;
  UINT8               parameters[0];
} CLI_BUFFER;

typedef struct {
  UINT8   varstoreIndex;
  UINT16  KnobOffset;
  UINT8   KnobSize;
//  UINT8   KnobValue[KnobSize];
} CLI_PROCESS_BIOS_KNOBS_RQST_PARAM;

typedef struct {
  UINT32  KnobXmlEntryPtr;
  UINT16  KnobXmlEntrySize;
  UINT8   varstoreIndex;
  UINT16  KnobOffset;
  UINT8   KnobSize;
//  UINT8   KnobDefValue[KnobSize];
//  UINT8   KnobCurrValue[KnobSize];
} CLI_PROCESS_BIOS_KNOBS_RSP_PARAM;

typedef struct {
  UINT8   varstoreIndex;
  UINT16  KnobOffset;
  UINT8   KnobSize;
  UINT64  KnobValue;
} CLI_UPDATE_BIOS_KNOBS_RQST_PARAM;

typedef struct {
  UINT32 rawAccess;
  struct {
    UINT32 SetupModified      :1;
    UINT32 Reserved           :31;
  } Status;
} CLI_UPDATE_BIOS_KNOBS_RSP_PARAM;

VOID       DxeRegisterCliApi ( UINT16 commandID, ClicmdHandlerFunc ClicmdHandler, VOID *Buffer );
VOID       SmmRegisterCliApi ( UINT16 commandID, ClicmdHandlerFunc ClicmdHandler, VOID *Buffer );
EFI_STATUS CliDxeEntryPoint ( VOID *XmlCliCom );

#pragma pack(pop)
#endif //_XML_CLI_API
