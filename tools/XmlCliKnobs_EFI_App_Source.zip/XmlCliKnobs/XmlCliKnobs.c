/** @file
    A simple, basic, EDK II native, "hello" application to verify that
    we can build applications without LibC.

    Copyright (c) 2010 - 2014, Intel Corporation. All rights reserved.<AS>
    This program and the accompanying materials
    are licensed and made available under the terms and conditions of the BSD License
    which accompanies this distribution. The full text of the license may be found at
    http://opensource.org/licenses/bsd-license.

    THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
    WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
**/
#include <XmlCli.h>

UINT32  GetDramSharedMbAddr(VOID)
{
  UINT32  DramMbAddress=0;
  IoWrite8(0x72, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG);
  DramMbAddress = (((UINT32)IoRead8(0x73)) << 16);
  IoWrite8(0x72, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG+1);
  DramMbAddress = ( DramMbAddress | (((UINT32)IoRead8(0x73)) << 24) );
  return DramMbAddress;
}

BOOLEAN XmlValid(UINT32 GbtXmlAddress)
{
  UINT32  XmlSize;
  CopyMem((VOID*)&XmlSize, (VOID*)(UINTN)GbtXmlAddress, 4);

  if (XmlSize != 0 ) {
    if ( ( CompareMem((VOID*)(UINTN)(GbtXmlAddress + 0x04), "<SYSTEM>", 8) == 0 ) &&
         ( CompareMem((VOID*)(UINTN)(GbtXmlAddress + XmlSize - 7 ), "</SYSTEM>", 9) == 0 ) ) {
      return TRUE;
    }
  }
  return FALSE;
}

EFI_STATUS ParseDramSharedMb(XML_CLI_DATA  *XmlCliData)
{
  SharedMemoryTable   *SharedMbTbl;
  UINT32              LegacyMbAddr=0;

  XmlCliData->DramMbAddress = GetDramSharedMbAddr();
  SharedMbTbl = (SharedMemoryTable*)(UINTN)XmlCliData->DramMbAddress;
  XmlCliData->MerlinXEnable = FALSE;
  //Print(L"\nInside Parse Dram shared MB DramMdAddress :0x%x\n",XmlCliData->DramMbAddress );
  if( (SharedMbTbl->Header.BIOS_Signature == SHARED_MB_BIOS_SIG) && (SharedMbTbl->Header.BIOS_Signature2 == SHARED_MB_BIOS_SIG) ) {
    //Print(L"Dram Shared MailBox is Valid,  SharedMbAddress: 0x%X\n", SharedMbTbl);
    if(SharedMbTbl->Entry[0].Signature == LEG_MAILBOX_SIG) {
      if( SharedMbTbl->Entry[0].Offset > 0xFFFF) {
        LegacyMbAddr = (UINT32)SharedMbTbl->Entry[0].Offset;
      } else {
        LegacyMbAddr = (UINT32)(UINTN)((UINT8*)SharedMbTbl + SharedMbTbl->Entry[0].Offset);
      }
      if( (SharedMbTbl->Header.CliSpecVersion.ReleaseVersion > 0) || (SharedMbTbl->Header.CliSpecVersion.MajorVersion > 6) ) {
        CopyMem((VOID*)&XmlCliData->GbtXmlAddress, (VOID*)(UINTN)(LegacyMbAddr + OFF_MERLINX_GBT_ADDRESS), 4);  // Get the GBT Xml address from merlin Offset since merlix is enabled
        XmlCliData->MerlinXEnable = TRUE;
      } else {
        CopyMem((VOID*)&XmlCliData->GbtXmlAddress, (VOID*)(UINTN)(LegacyMbAddr + OFF_GBT_ADDRESS), 4);
      }
      if(XmlValid(XmlCliData->GbtXmlAddress)) {
        CopyMem((VOID*)&XmlCliData->XmlSize, (VOID*)(UINTN)XmlCliData->GbtXmlAddress, 4);
        //Print(L"PlatformConfig.xml is Valid,  XMLAddress: 0x%X  XmlSize = 0x%X\n", XmlCliData->GbtXmlAddress, XmlCliData->XmlSize);
        CopyMem((VOID*)&XmlCliData->SetupKnobAddr, (VOID*)(UINTN)(LegacyMbAddr + SETUP_KNOB_ADDRESS_OFF), 4);
        CopyMem((VOID*)&XmlCliData->SetupKnobSize, (VOID*)(UINTN)(LegacyMbAddr + SETUP_KNOB_SIZE_OFF), 4);
      } else {
        Print(L"PlatformConfig.xml is not Valid,  XMLAddress: 0x%X  XmlSize = 0x%X\n", XmlCliData->GbtXmlAddress, XmlCliData->XmlSize);
        return EFI_NOT_FOUND;
      }
    }
    if(SharedMbTbl->Entry[1].Signature == CLI_REQ_SIG) {
      XmlCliData->CliReqBuff = SharedMbTbl->Entry[1].Offset;
    }
    if(SharedMbTbl->Entry[2].Signature == CLI_RES_SIG) {
      XmlCliData->CliResBuff = SharedMbTbl->Entry[2].Offset;
    }
    //Print(L" SetupKnobAddr: 0x%X  SetupKnobSize = 0x%X  \n CliReqBuff = 0x%X  CliResBuff =  = 0x%X\n", XmlCliData->SetupKnobAddr, XmlCliData->SetupKnobSize, XmlCliData->CliReqBuff, XmlCliData->CliResBuff);
  } else {
    Print(L"Dram Shared MailBox not Valid!, Address: 0x%X , aborting..\n", SharedMbTbl);
    return EFI_NOT_FOUND;
  }

  if( (XmlCliData->SetupKnobAddr == 0) || (XmlCliData->SetupKnobSize == 0) || (XmlCliData->CliReqBuff == 0) | (XmlCliData->CliResBuff == 0) ) {
    Print(L"CLI buffers or Xml Setup Knobs Data not Valid!\n");
    return EFI_NOT_FOUND;
  }
  return EFI_SUCCESS;
}

UINTN GetToKnobEnd(UINTN XmlStartPointer)
{
  UINTN   Count;
  UINT64  XmlKnobEndTag;

  for (Count = 0; Count < 0x10000; Count++) {  // assuming each knob entry size wont exceed 64KB limit
    XmlKnobEndTag = *(UINT64*)(XmlStartPointer+Count);
    if((XmlKnobEndTag & BIOS_KNOB_END_TAG_1_MASK) == BIOS_KNOB_END_TAG_1) {
      return (XmlStartPointer + Count + BIOS_KNOB_END_TAG_1_SIZE - 1);
    }
    if((XmlKnobEndTag & BIOS_KNOB_END_TAG_2_MASK) == BIOS_KNOB_END_TAG_2) {
      return (XmlStartPointer + Count + BIOS_KNOB_END_TAG_2_SIZE - 1);
    }
  }
  return XmlStartPointer;
}

BOOLEAN GetAtriVal( UINTN  XmlPointer, CHAR8 *AtriValue)
{
  UINT16   Count;

  AtriValue[0] = 0;
  for (Count = 0; Count < 0x4000; Count++) {  // assuming each knob entry size wont exceed 16KB limit
    AtriValue[Count] = *(CHAR8*)(XmlPointer+Count);
    if( AtriValue[Count] == BIOS_KNOB_ATTR_END) {
      AtriValue[Count] = 0;
      break;
    }
  }
  if(AtriValue[0] == 0) {
    return FALSE;
  } else {
    return TRUE;
  }
}

BOOLEAN ParseAttribute( UINTN  XmlPointer, UINT64  AtriTag1, UINT64  AtriTag2, UINT64 AtriTagMask, UINT8 AtriTagSize, VOID *AtriValue, BOOLEAN IsAtriValInteger)
{
  UINTN   Count;
  UINT64  KnobAtriTag, AtriTag1Mask, AtriTag2Mask=0;
  UINT8   AtriTag1Size=AtriTagSize, AtriTag2Size=0;
  BOOLEAN AtriFound=FALSE;
  CHAR16  StringKnobData[64];

  if (AtriTag2 != 0) {
    AtriTag1Size = 8;
    AtriTag1Mask = 0xFFFFFFFFFFFFFFFF;
    AtriTag2Size = AtriTagSize;
    AtriTag2Mask = AtriTagMask;
  } else {
    AtriTag1Mask = AtriTagMask;
  }

  for (Count = 0; Count < 0x10000; Count++) {  // assuming each knob entry size wont exceed 64KB limit
    KnobAtriTag = *(UINT64*)(XmlPointer+Count);
    if( (KnobAtriTag & AtriTag1Mask) == AtriTag1) { // matches first tag
      if (AtriTag2 != 0) {
        KnobAtriTag = *(UINT64*)(XmlPointer+Count+AtriTag1Size);
        if( (KnobAtriTag & AtriTag2Mask) == AtriTag2) { // Matches second tag
          AtriFound = GetAtriVal(XmlPointer+Count+AtriTag1Size+AtriTag2Size, (CHAR8*)AtriValue);
          break;
        }
      } else {
        AtriFound = GetAtriVal(XmlPointer+Count+AtriTag1Size, (CHAR8*)AtriValue);
        break;
      }
    }
    if( ((KnobAtriTag & BIOS_KNOB_END_TAG_1_MASK) == BIOS_KNOB_END_TAG_1) || ((KnobAtriTag & BIOS_KNOB_END_TAG_2_MASK) == BIOS_KNOB_END_TAG_2) ) {
      break;
    }
  }

  if ( AtriFound && IsAtriValInteger) {
    AsciiStrToUnicodeStr((CHAR8*)AtriValue, StringKnobData);
    if (EFI_ERROR(ShellConvertStringToUint64(StringKnobData, AtriValue, FALSE, TRUE))) {
      AtriFound = FALSE;
    }
  }
  return AtriFound;
}

VOID MemSaveAsFile( CHAR16 *Destination, CHAR16 *AddressStr, CHAR16 *SizeStr )
{
  UINTN                 ReadSize=0, Address=0;
  SHELL_FILE_HANDLE     DestHandle=NULL;
  EFI_STATUS            Status;
  VOID                  *Buffer;

  // open file with create enabled
  Status = ShellOpenFileByName(Destination, &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
  if (EFI_ERROR(Status)) {
    Print(L"Cannot Open Destination File \n");
    return;
  }

  if (EFI_ERROR(ShellConvertStringToUint64(SizeStr, &ReadSize, FALSE, TRUE))) {
    Print(L"File Size is 0!\n");
    return;
  }

  if (EFI_ERROR(ShellConvertStringToUint64(AddressStr, &Address, FALSE, TRUE))) {
    Print(L"Address to copy from is 0!\n");
    return;
  }

  Buffer = AllocateZeroPool(ReadSize);
  if (Buffer == NULL) {
    Print(L"Error Allocating ZeroPool, PoolSize = 0x%X \n", ReadSize);
    return;
  }
  CopyMem(Buffer, (VOID*)(UINTN)Address, ReadSize);
  Status = FileHandleWrite(DestHandle, &ReadSize, Buffer);
  if (EFI_ERROR(Status)) {
    Print(L"Destination File Write error \n");
    return;
  }

  // close files
  if (DestHandle != NULL) {
    FileHandleClose(DestHandle);
    DestHandle = NULL;
  }
  if (Buffer != NULL) {
    FreePool(Buffer);
  }
  return;
}

VOID FetchHdrAndKnobs(XML_CLI_DATA  *XmlCliData, CHAR16  *BiosKnobsFileName)
{
  EFI_STATUS          Status;
  UINTN               XmlByteCount=0;
  UINT8               EleEndTagCount=0;
  SHELL_FILE_HANDLE   DestHandle=NULL;
  VOID                *Buffer=NULL;

  // open file with create enabled
  if (BiosKnobsFileName == NULL) {
    Status = ShellOpenFileByName(L"BiosKnobs.xml", &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
    Print(L"Saved Bios Knobs section of XML as BiosKnobs.xml\n");
  } else {
    Status = ShellOpenFileByName(BiosKnobsFileName, &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
    Print(L"Saved Bios Knobs section of XML as %S\n", BiosKnobsFileName);
  }
  if (EFI_ERROR(Status)) {
    Print(L"Cannot Open Destination File \n");
    return;
  }

  Buffer = AllocateZeroPool(XmlCliData->SetupKnobSize+0x1000);
  if (Buffer == NULL) {
    Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", (XmlCliData->SetupKnobSize+0x1000));
    return;
  }

  while(EleEndTagCount < 3) {
    if(*(UINT16*)(UINTN)(XmlCliData->GbtXmlAddress+4+XmlByteCount) == 0x3E2F)  EleEndTagCount++;    // '/>'
    XmlByteCount++;
  }
  XmlByteCount = XmlByteCount + 3;  // take >\r\n into account
  CopyMem(Buffer, (VOID*)(UINTN)(XmlCliData->GbtXmlAddress+4), XmlByteCount);
  CopyMem((UINT8*)Buffer+XmlByteCount, (VOID*)(UINTN)XmlCliData->SetupKnobAddr, XmlCliData->SetupKnobSize);  // Copy Setup knobs section
  XmlByteCount = XmlByteCount + XmlCliData->SetupKnobSize;
  EleEndTagCount = 0;
  while(EleEndTagCount < 40) {
    EleEndTagCount++;    // '</SYSTEM>\r\n'
    if(*(UINT8*)(UINTN)(XmlCliData->GbtXmlAddress+4+XmlCliData->XmlSize-EleEndTagCount) == 0x3C) {
      break;
    }
  }
  CopyMem((UINT8*)Buffer+XmlByteCount, (VOID*)(UINTN)(XmlCliData->GbtXmlAddress+4+XmlCliData->XmlSize-EleEndTagCount), EleEndTagCount);
  XmlByteCount = XmlByteCount + EleEndTagCount;
  Status = FileHandleWrite(DestHandle, &XmlByteCount, Buffer);
  if (EFI_ERROR(Status)) {
    Print(L"Destination File Write error \n");
    FreePool(Buffer);
    return;
  }

  if (DestHandle != NULL) {
    FileHandleClose(DestHandle);
    DestHandle = NULL;
  }
  FreePool(Buffer);
}

VOID ParseXmlKnobs(KNOB_INPUT_DATA  *KnobDataPtr, XML_CLI_DATA  *XmlCliData)
{
  UINTN   XmlStartPointer, XmlEndPointer=(UINTN)(XmlCliData->SetupKnobAddr+XmlCliData->SetupKnobSize);
  UINT64  XmlKnobTag;
  UINT16  ReqKnobIndex=0;
  CHAR8   XmlKnobData[64];

  XmlCliData->ReqKnobEntriesProcessed=0;

  for (XmlStartPointer=(UINTN)XmlCliData->SetupKnobAddr; XmlStartPointer < XmlEndPointer; XmlStartPointer++) {
    XmlKnobTag = ((*(UINT64*)XmlStartPointer) & BIOS_KNOB_START_TAG_MASK) ;
    if(XmlKnobTag == BIOS_KNOB_START_TAG) { // Found Knob entry start, get Name
      if(ParseAttribute(XmlStartPointer, BIOS_KNOB_NAME_TAG, 0, BIOS_KNOB_NAME_TAG_MASK, BIOS_KNOB_NAME_TAG_SIZE, (VOID*)XmlKnobData, FALSE) == FALSE) continue;
      for (ReqKnobIndex=0; ReqKnobIndex < XmlCliData->ReqKnobEntries; ReqKnobIndex++) {
        if( (KnobDataPtr[ReqKnobIndex].ReqKnobName[0] == 0) || (KnobDataPtr[ReqKnobIndex].KnobFoundInXml) ) continue;   // Invalid or Already processed entry
        if(AsciiStrCmp(KnobDataPtr[ReqKnobIndex].ReqKnobName, XmlKnobData) == 0) { // Requested Knob found in XML, now get the knob details form XML
          if (ParseAttribute(XmlStartPointer, BIOS_KNOB_VARDID_TAG_1, BIOS_KNOB_VARDID_TAG_2, BIOS_KNOB_VARDID_TAG_2_MASK, BIOS_KNOB_VARDID_TAG_2_SIZE, (VOID*)XmlKnobData, TRUE)) {
            CopyMem(&KnobDataPtr[ReqKnobIndex].KnobVarId, (VOID*)XmlKnobData, 1);
          } else {
            KnobDataPtr[ReqKnobIndex].KnobVarId = 0xFF;
          }

          if(ParseAttribute(XmlStartPointer, BIOS_KNOB_SIZE_TAG, 0, BIOS_KNOB_SIZE_TAG_MASK, BIOS_KNOB_SIZE_TAG_SIZE, (VOID*)XmlKnobData, TRUE)) {
            CopyMem(&KnobDataPtr[ReqKnobIndex].KnobSize, (VOID*)XmlKnobData, 1);
          } else {
            KnobDataPtr[ReqKnobIndex].KnobSize = 1;
          }

          if(ParseAttribute(XmlStartPointer, BIOS_KNOB_OFFSET_TAG, 0, BIOS_KNOB_OFFSET_TAG_MASK, BIOS_KNOB_OFFSET_TAG_SIZE, (VOID*)XmlKnobData, TRUE)) {
            CopyMem(&KnobDataPtr[ReqKnobIndex].KnobOffset, (VOID*)XmlKnobData, 2);
          } else {
            KnobDataPtr[ReqKnobIndex].KnobOffset = 0;
          }

          KnobDataPtr[ReqKnobIndex].KnobFoundInXml = TRUE;
          XmlCliData->ReqKnobEntriesProcessed++;
        }
      }
      XmlStartPointer = GetToKnobEnd(XmlStartPointer);
    }
    if(XmlCliData->ReqKnobEntriesProcessed == XmlCliData->ReqKnobValidEntries) break;  // done with requested entries, no need to parse the XML further
  }
}

UINT16  ParseInputKnobs(KNOB_INPUT_DATA  *KnobDataPtr, CHAR8 *KnobsString)
{
  UINT8   AsciiCount=0, StrValCount=0, FirstItera=0, InrFlag=0;
  CHAR16  ReqKnobStrValue[24];
  CHAR8   ReqKnobAsciiVal[24];
  UINT64  ReqKnobVal=0;
  UINT16  KnobEntryCount=0;

  ReqKnobStrValue[0] = 0;
  ReqKnobAsciiVal[0] = 0;
  do {
    //Print(L"0x%x  StrPointer = 0x%X \n", (*(UINT8*)KnobsString), KnobsString);
    if (FirstItera) { // skip for first iteration
      KnobsString++;
    } else {
      FirstItera++;
    }
    if (*KnobsString == ' ') {
      continue;
    }
    if ((*KnobsString == ';') || (*KnobsString == '[') ) { // treat comment accordingly
      while( (*KnobsString != '\n') && (*KnobsString != 0) ) { // loop until we reach end of line or end of string.
        KnobsString++;
      }
    }

    if (*KnobsString == '=') { // Lets read the given value
      KnobsString++;
      while(*KnobsString) {
        if (*KnobsString == ' ') {
          KnobsString++;
          continue;
        }
        if ((*KnobsString == ',') || (*KnobsString == '\n') || (*KnobsString == '\r')) {
          break;
        }
        ReqKnobAsciiVal[StrValCount] = *KnobsString;
        StrValCount++;
        KnobsString++;
      }
    }
    if ((*KnobsString == ',') || (*KnobsString == '\n')  || (*KnobsString == '\r') || (*KnobsString == 0)) { // end of given knob entry
      if (KnobDataPtr[KnobEntryCount].ReqKnobName[0] != 0) {
        ReqKnobAsciiVal[StrValCount] = 0;   // Add a NULL char
        ReqKnobVal = 0;
        if (ReqKnobAsciiVal[0] != 0) {
          AsciiStrToUnicodeStr((CHAR8*)ReqKnobAsciiVal, ReqKnobStrValue);
          if (EFI_ERROR(ShellConvertStringToUint64(ReqKnobStrValue, &ReqKnobVal, FALSE, TRUE))) {
            ReqKnobVal = 0;
            KnobDataPtr[KnobEntryCount].InvalidInputKnobVal = TRUE;
          }
        } else {
          KnobDataPtr[KnobEntryCount].InvalidInputKnobVal = TRUE;
        }
        KnobDataPtr[KnobEntryCount].ReqKnobValue = ReqKnobVal;
        //Print(L" [%d]  ReqKnob Name = %a, ReqKnobValue = 0x%X \n", KnobEntryCount, KnobDataPtr[KnobEntryCount].ReqKnobName, KnobDataPtr[KnobEntryCount].ReqKnobValue);
        StrValCount = 0;
        KnobEntryCount++;
      }
      InrFlag = 0;
      while((*KnobsString == ',') || (*KnobsString == '\n')  || (*KnobsString == '\r')) { // get past the Knob and line ending characters
        KnobsString++;
        InrFlag = 1;
      }
      if (InrFlag)  KnobsString--;  // correct the incremental ++, since we will increment again on top of this loop
      AsciiCount = 0;
      if (*KnobsString == 0) {
        break;
      }
    } else {
      KnobDataPtr[KnobEntryCount].ReqKnobName[AsciiCount] = (CHAR8)*KnobsString;
      AsciiCount++;
    }
  } while(*KnobsString);

  return KnobEntryCount;
}

VOID PrepareKnobsCliParamBuff(KNOB_INPUT_DATA  *KnobDataPtr, XML_CLI_DATA  *XmlCliData)
{
  UINT16      count;
  UINTN       CurrCliReqBuffPtr=(UINTN)(XmlCliData->CliReqBuff+sizeof(CLI_BUFFER));

  for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
    if( (KnobDataPtr[count].ReqKnobName[0] == 0) || (KnobDataPtr[count].KnobFoundInXml == FALSE) ) continue;   // skip invalid entry
    if( (XmlCliData->CommandId != READ_BIOS_KNOBS_OPCODE) && (KnobDataPtr[count].InvalidInputKnobVal) ) {
      Print(L"Warning: Invalid Input Value, Ignoring Requested Knob Entry= %a \n", KnobDataPtr[count].ReqKnobName);
      XmlCliData->ReqKnobEntriesProcessed--;  // Decrement Processed Knobs count
      continue;   // dont/prevent program invalid values
    }
    ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->varstoreIndex  = KnobDataPtr[count].KnobVarId;
    ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->KnobOffset     = KnobDataPtr[count].KnobOffset;
    ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->KnobSize       = KnobDataPtr[count].KnobSize;
    CopyMem((VOID*)(CurrCliReqBuffPtr+sizeof(CLI_PROCESS_BIOS_KNOBS_RQST_PARAM)), &KnobDataPtr[count].ReqKnobValue, KnobDataPtr[count].KnobSize);
    CurrCliReqBuffPtr = CurrCliReqBuffPtr + sizeof(CLI_PROCESS_BIOS_KNOBS_RQST_PARAM) + KnobDataPtr[count].KnobSize;
  }
}

EFI_STATUS TriggerXmlCliApi(KNOB_INPUT_DATA  *KnobDataPtr, XML_CLI_DATA  *XmlCliData)
{
  EFI_STATUS  Status;
  UINTN       ResPointer, XmlPointer, DefVal=0, CurrVal=0;
  UINT8       KnobSize, VarId;
  UINT16      KnobOffset, count, Retries;
  CHAR8       XmlKnobData[64];
  UINTN       CurrCliResBuffPtr=(UINTN)(XmlCliData->CliResBuff+sizeof(CLI_BUFFER));
  CLI_BUFFER  *CliResBuffHdr=(CLI_BUFFER*)(UINTN)XmlCliData->CliResBuff;
  CHAR8       *ComandSideEffect[4] = {"NoSideEffect", "WarmResetRequired", "PowerGoodResetRequired", "Reserved"};

  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->commandID        = XmlCliData->CommandId;
  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->flags.rawAccess  = 0;
  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->status           = 0;
  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->parametersSize   = XmlCliData->ReqKnobEntriesProcessed;
  if(XmlCliData->MerlinXEnable) {
    ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->signature      = CLI_MERLINX_SGN_REQUEST_READY;
  } else {
    ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->signature      = CLI_SGN_REQUEST_READY;
  }
  ZeroMem ((VOID*)(UINTN)XmlCliData->CliResBuff, sizeof(CLI_BUFFER));    // clear/initialize response buffer
  if(XmlCliData->DxeLoop){
    XML_CLI_API *XmlCliApi;
    EFI_GUID    gXmlCliCommonGuid = { 0xbf030b10, 0x2d9b, 0x4e71, { 0xa0, 0xc4, 0xbc, 0x99, 0x10, 0x57, 0x9d, 0x40 } };
  
    Status = gBS->LocateProtocol(&gXmlCliCommonGuid, NULL, (VOID**)&XmlCliApi);
    if (EFI_ERROR(Status)) { // XmlCliCommon Protocol not published.
      Print(L"LocateProtocol on XmlCliCommon Failed, returning! \n");
      return EFI_NOT_FOUND;
    }
    Print(L"Entering Cli Loop via Dxe Entry Point.. \n");
    Status = XmlCliApi->DxeCliEntry((VOID*)XmlCliApi);
    Print(L"XmlCliApi->DxeCliEntry() Status: %r\n", Status);
  } else {
    Print(L"Entering Cli Loop via S/W SMI.. \n");
    IoWrite8(SW_SMI_PORT, SW_XML_CLI_ENTRY);    // Trigger S/W SMI
  }

  for(Retries=0; Retries < 10; Retries++) {
    if( (CliResBuffHdr->signature == CLI_SGN_RESPONCE_READY) || (CliResBuffHdr->signature == CLI_MERLINX_SGN_RESPONCE_READY) ) {
      if( (CliResBuffHdr->status == 0) && (CliResBuffHdr->commandID == XmlCliData->CommandId) && (CliResBuffHdr->flags.fields.wrongParameter == 0) && (CliResBuffHdr->flags.fields.CannotExecute == 0) ) {
        Print (L"|---|------------|------------|---------------------------------------------\n");
        if (XmlCliData->CommandId != LOAD_DEFAULT_KNOBS_OPCODE) {
          Print (L"|KSz| DefaultVal | CurrentVal |     Knob Name                               \n");
        } else {
          Print (L"|KSz| PreviusVal | RestordVal |     Knob Name                               \n");
        }
      Print (L"|---|------------|------------|---------------------------------------------\n");
        for (ResPointer=CurrCliResBuffPtr; ResPointer < (CurrCliResBuffPtr+CliResBuffHdr->parametersSize);) {
          XmlPointer = (UINTN)((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobXmlEntryPtr;
          VarId = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->varstoreIndex;
          KnobOffset = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobOffset;
          KnobSize = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobSize;
          DefVal = CurrVal = 0;
          CopyMem(&DefVal, (VOID*)(ResPointer+sizeof(CLI_PROCESS_BIOS_KNOBS_RSP_PARAM)), KnobSize);
          CopyMem(&CurrVal, (VOID*)(ResPointer+sizeof(CLI_PROCESS_BIOS_KNOBS_RSP_PARAM)+KnobSize), KnobSize);
          ResPointer = ResPointer + sizeof(CLI_PROCESS_BIOS_KNOBS_RSP_PARAM) + (KnobSize * 2);
          if(ParseAttribute(XmlPointer, BIOS_KNOB_NAME_TAG, 0, BIOS_KNOB_NAME_TAG_MASK, BIOS_KNOB_NAME_TAG_SIZE, (VOID*)XmlKnobData, FALSE) == FALSE) continue;
          if (KnobSize <=4) {
            Print (L"| %X | 0x%-8X | 0x%-8X | %a \n", KnobSize, DefVal, CurrVal, XmlKnobData);
          } else {
            Print (L"| %X | 0x%-16lX | 0x%-16lX | %a \n", KnobSize, DefVal, CurrVal, XmlKnobData);
          }
          if (XmlCliData->CommandId != LOAD_DEFAULT_KNOBS_OPCODE) {
            for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
              if( (KnobDataPtr[count].ReqKnobName[0] == 0) || (KnobDataPtr[count].KnobFoundInXml == FALSE) )continue;   // skip invalid entry
              if(AsciiStrCmp(KnobDataPtr[count].ReqKnobName, XmlKnobData) == 0) {
                KnobDataPtr[count].DefKnobValue   = DefVal;
                KnobDataPtr[count].CurrKnobValue  = CurrVal;
                KnobDataPtr[count].KnobProcByCli  = TRUE;
                break;
              }
            }
          }
        }
        Print (L"|---|------------|------------|---------------------------------------------\n");
        Print (L"Side-Effect of XmlCli Knobs command is = \"%a\"\n", ComandSideEffect[CliResBuffHdr->flags.fields.commandSideEffects]);
        return EFI_SUCCESS;
      }
    }
    IoRead8(0x80);    // dummy read to simulate the delay
  }
  Print(L"XML CLI Knobs Operation returned with error!, Aborting..\n");
  return EFI_NOT_FOUND;
}

VOID FreeBuffers(VOID *KnobsString, VOID *KnobDataPtr)
{
  if (KnobsString != NULL) {
    FreePool(KnobsString);
  }
  if (KnobDataPtr != NULL) {
    FreePool(KnobDataPtr);
  }
}

CHAR8* GetInKnobsString(CHAR16 *KnobsInFormat, CHAR16 *KnobArg)
{
  EFI_STATUS          Status;
  UINTN               ReadSize;
  SHELL_FILE_HANDLE   SourceHandle=NULL;
  CHAR8               *KnobsString=NULL;

  if(KnobsInFormat[0] == L'-') {
    if(KnobsInFormat[1] == L's') { // Knobs input in String format
      ReadSize = StrLen (KnobArg);
      KnobsString = AllocateZeroPool(ReadSize+4);  // 4 bytes with NULL value as a safety buffer
      if (KnobsString == NULL) {
        Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", ReadSize);
        return NULL;
      }
      UnicodeStrToAsciiStr(KnobArg, KnobsString);
    } else if (KnobsInFormat[1] == L'f') { // Knobs Input in cfg file format
      Status = ShellOpenFileByName(KnobArg, &SourceHandle, EFI_FILE_MODE_READ, 0);
      if (EFI_ERROR(Status)) {
        Print(L"Cannot Open Source File \n");
        return NULL;
      }
      Status = FileHandleGetSize(SourceHandle, &ReadSize);
      if (EFI_ERROR(Status)) {
        Print(L"Cannot Get Source File Size \n");
        return NULL;
      }
      KnobsString = AllocateZeroPool(ReadSize+4);  // 4 bytes with NULL value as a safety buffer
      if (KnobsString == NULL) {
        Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", ReadSize);
        return NULL;
      }
      Status = FileHandleRead(SourceHandle, &ReadSize, KnobsString);
      if (EFI_ERROR(Status)) {
        Print(L"Source Read File error \n");
        FreePool(KnobsString);
        return NULL;
      }
      if (SourceHandle != NULL) {
        FileHandleClose(SourceHandle);
        SourceHandle = NULL;
      }
    }
  }
  return KnobsString;
}

VOID PrintUsage(VOID)
{
  Print(L" Application Usage: <XmlCliKnobs.efi Operation [-s|-f] [KnobsStr|KnobsCfgFile]>\n");
  Print(L" (Save XML)       : <XmlCliKnobs.efi GX>\n");
  Print(L" (XML to MyFile)  : <XmlCliKnobs.efi GX  fs0:\\MyBiosKnobs.xml>\n");
  Print(L" For following commands use DXE as aditional last arg to have \n\tDxe loop as Cli Entry point, Default is S/W SMI based\n");
  Print(L" (Load Defaults)  : <XmlCliKnobs.efi LD \n");
  Print(L" (Read Only)      : <XmlCliKnobs.efi RO  -s  \"SetShellFirst, ForceSetup\">\n");
  Print(L" (Read+Verify)    : <XmlCliKnobs.efi RO  -s  \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (Read+Verfy .cfg): <XmlCliKnobs.efi RO  -f  fs0:\\BiosKnobs.cfg>\n");
  Print(L" (Program+verify) : <XmlCliKnobs.efi AP  -s  \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (Prog+verfy .cfg): <XmlCliKnobs.efi AP  -f  fs0:\\BiosKnobs.cfg>\n");
  Print(L" (LD+AP+verify)   : <XmlCliKnobs.efi RM  -s  \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L"(LD+AP+verfy .cfg): <XmlCliKnobs.efi RM  -f  fs0:\\BiosKnobs.cfg>\n");
}

/***
  Print a welcoming message.
  Establishes the main structure of the application.
  @retval  0         The application exited normally.
  @retval  Other     An error occurred.
***/
INTN EFIAPI ShellAppMain ( IN UINTN Argc, IN CHAR16 **Argv )
{
  EFI_STATUS          Status;
  CHAR16              *Operation, *EntryMode;
  CHAR8               *KnobsString=NULL;
  CHAR16              *BiosKnobsFileName=NULL;
  KNOB_INPUT_DATA     *KnobDataPtr=NULL;
  XML_CLI_DATA        XmlCliData;
  UINT16              count, VerifyErrCnt=0;

  Print(L"Welcome to XML CLI Knobs EFI Utility, Version 0.7\n");

  if(Argc < 2) {
    Print(L"This EFI App expects min 1 args; See below for Usage and some eg.\n");
    PrintUsage();
    return(0);
  }
  Operation = (CHAR16*)Argv[1];

  SetMem(&XmlCliData, sizeof(XmlCliData), 0);   // Initialize the struct to 0
  Status = ParseDramSharedMb(&XmlCliData);
  if (EFI_ERROR (Status)) { 
    Print(L"Aborting due to Error!\n");
    return(0);
  }

  XmlCliData.DxeLoop = FALSE;  // This means default to S/W SMI method. 
  if( (Operation[0] == L'R') && (Operation[1] == L'O') ) { // Operation == Read Bios Knobs ??
    XmlCliData.CommandId = READ_BIOS_KNOBS_OPCODE;
  } else if( (Operation[0] == L'A') && (Operation[1] == L'P') ) { // Operation == Append ??
    XmlCliData.CommandId = APPEND_BIOS_KNOBS_OPCODE;
  } else if( (Operation[0] == L'R') && (Operation[1] == L'M') ) { // Operation == Restore Modify ??
    XmlCliData.CommandId = RESTOREMODIFY_KNOBS_OPCODE;
  } else if( (Operation[0] == L'L') && (Operation[1] == L'D') ) { // Operation == Load Defaults ??
    XmlCliData.CommandId = LOAD_DEFAULT_KNOBS_OPCODE;
    if(Argc >= 3) {
      EntryMode = (CHAR16*)Argv[2];
      if( (EntryMode[0] == L'D') && (EntryMode[1] == L'X') && (EntryMode[2] == L'E') ) {  // compare with 'DXE'
        XmlCliData.DxeLoop = TRUE;
      }
    }
    Status = TriggerXmlCliApi(KnobDataPtr, &XmlCliData);
    return(0);
  } else if( (Operation[0] == L'G') && (Operation[1] == L'X') ) { // Operation == Save Bios knobs XML ??
    if(Argc > 2) BiosKnobsFileName = (CHAR16*)Argv[2];
    FetchHdrAndKnobs(&XmlCliData, BiosKnobsFileName);    // fetch and save XML Knobs section to BiosKnobs.xml file for future reference
    return(0);
  } else if( (Operation[0] == L'M') && (Operation[1] == L'S') ) { // Operation == Save given Memory details in given File ??
    if(Argc == 5) {
      MemSaveAsFile( Argv[2], Argv[3], Argv[4] );
    }
    return(0);
  } else {
    Print(L"Unsupported Operation!, aborting..\n");
    return(0);
  }

  if(Argc < 4) {
    Print(L"For this operation App expects min 3 args; See below for Usage and some eg.\n");
    PrintUsage();
    return(0);
  }
  if(Argc > 4) {
    EntryMode = (CHAR16*)Argv[4];
    if( (EntryMode[0] == L'D') && (EntryMode[1] == L'X') && (EntryMode[2] == L'E') ) {  // compare with 'DXE'
      XmlCliData.DxeLoop = TRUE;
    }
  }
  KnobsString = GetInKnobsString(Argv[2], Argv[3]);
  if (KnobsString == NULL) {
    return(0);
  }
//  Print(L"Input Args: <%S> <%S> <%S>\n", (CHAR16*)Argv[1], (CHAR16*)Argv[2], (CHAR16*)Argv[3]);
//  Print(L"Input Knob string : %a\n", KnobsString);

  KnobDataPtr = AllocateZeroPool(sizeof(KNOB_INPUT_DATA)*0x2000); // 8K Knobs handling capability
  if (KnobDataPtr == NULL) {
    Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", (sizeof(KNOB_INPUT_DATA)*0x2000));
    FreeBuffers(KnobsString, KnobDataPtr);
    return(0);
  }

//    Print(L"Knob String:  |%a|\n", KnobsString);
  XmlCliData.ReqKnobEntries = ParseInputKnobs(KnobDataPtr, KnobsString);
//  Print(L"No of Entries found: %d\n", XmlCliData.ReqKnobEntries);
  for (count=0; count < XmlCliData.ReqKnobEntries; count++) {
    if(KnobDataPtr[count].ReqKnobName[0] == 0) continue;
    XmlCliData.ReqKnobValidEntries++;
//    Print(L"Knob Entry:  KnobName = %a   ReqVal (H) = %d (0x%X)\n", KnobDataPtr[count].ReqKnobName, KnobDataPtr[count].ReqKnobValue, KnobDataPtr[count].ReqKnobValue);
  }
  ParseXmlKnobs(KnobDataPtr, &XmlCliData);

  if(XmlCliData.ReqKnobEntriesProcessed) {
    PrepareKnobsCliParamBuff(KnobDataPtr, &XmlCliData);
    if (XmlCliData.ReqKnobEntriesProcessed == 0) {
      Print(L"No Input entries processed!\n");
      FreeBuffers(KnobsString, KnobDataPtr);
      return(0);
    }
    Status = TriggerXmlCliApi(KnobDataPtr, &XmlCliData);
    if (!EFI_ERROR(Status)) {   // if XML CLI API return with success
      for (count=0; count < XmlCliData.ReqKnobEntries; count++) {
        if( (KnobDataPtr[count].ReqKnobName[0] == 0) || (KnobDataPtr[count].KnobFoundInXml == FALSE) || (KnobDataPtr[count].InvalidInputKnobVal) ) continue;   // skip invalid entry
        if(KnobDataPtr[count].KnobProcByCli) {
          if (KnobDataPtr[count].CurrKnobValue != KnobDataPtr[count].ReqKnobValue) {
            VerifyErrCnt++;
            Print (L"Verify Fail: Knob = %a  ReqVal = 0x%lX CurrVal = 0x%lX \n", KnobDataPtr[count].ReqKnobName, KnobDataPtr[count].ReqKnobValue, KnobDataPtr[count].CurrKnobValue);
          }
        }
      }
      if(VerifyErrCnt) {
        Print(L"Verify Failed!\n");
      } else {
        Print(L"Verify Passed!\n");
      }
    }
  } else {
    Print(L"No Input entries processed!\n");
  }
  FreeBuffers(KnobsString, KnobDataPtr);
  return(0);
}
