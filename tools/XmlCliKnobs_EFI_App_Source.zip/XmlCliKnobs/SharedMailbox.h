/** @file
  Definitions for Shared Mailbox table

@copyright
 Copyright (c) 2015 - 2018 Intel Corporation. All rights reserved
 This software and associated documentation (if any) is furnished
 under a license and may only be used or copied in accordance
 with the terms of the license. Except as permitted by the
 license, no part of this software or documentation may be
 reproduced, stored in a retrieval system, or transmitted in any
 form or by any means without the express written consent of
 Intel Corporation.
 This file contains a 'Sample Driver' and is licensed as such
 under the terms of your license agreement with Intel or your
 vendor. This file may be modified by the user, subject to
 the additional terms of the license agreement.

@par Specification Reference:

**/

#ifndef _SHARED_MEM_DIV
#define _SHARED_MEM_DIV


#define OS_GETVAR_FAIL                0xCE
#define SKIP_DEF_VAR_SNAPSHOT         0x51
#define BOOT_FLAG_EN                  0xE9
#define LEGACY_CLI_KNOBS_FORMAT       0x00
#define GANGES_XML                    0x01
#define FLAT_KNOBS_XML                0x02
#define XMLCLI_DONE_POSTCODE          0xFC
#define XMLCLI_MERLINX_DONE_POSTCODE  0xDE

#define OFF_SEND_KNOBS_SIG            0x08
#define OFF_GBT_ADDRESS               0x0C
#define OFF_LT_RESET                  0x10
#define OFF_POST_DONE                 0x12
#define OFF_GBT_COMPRESSED_ADDRESS    0x1C
#define OFF_PRPOST                    0x32
#define LEG_KNOB_ADDRESS_OFF          0x34
#define LEG_KNOB_SIZE_OFF             0x38
#define SETUP_KNOB_ADDRESS_OFF        0x3C
#define SETUP_KNOB_SIZE_OFF           0x40
#define DRAM_SHARED_MB_OFF            0x44
#define KNOB_XML_ENTRY_OFF            0x48

#define OFF_MERLINX_XML_CLI_ENABLED   0x28
#define OFF_MERLINX_GBT_ADDRESS       0x50
#define OFF_MERLINX_GBT_COMPR_ADDR    0x5C

#define OFF_XML_CLI_TEMP_ADDR         0x60

#define ITP_XDP_VEND_DEV_ID           0x14928086    // custom define for ITP vendor Device ID
#define ITP_XDP_BAR_NO                0xD           // custom define for ITP DAL interface

#pragma pack(push, 1)

typedef struct SharedMemoryHeaderEntry_ {
  UINT32  BIOS_Signature;
  union {
    struct {
      UINT32  EntriesNumber : 8;
      UINT32  FirstEntryOffset : 8;
      UINT32  EntrySize : 8;
      UINT32  ReservedByte : 7;
      UINT32  ValidHeader : 1;
    } EntriesInfo;
  } _u1;
  UINT32  BIOS_Signature2;
  UINT32  CheckSum;
  struct {
    UINT32  Reserved0 : 8;
    UINT32  DeviceID : 16;
    UINT32  BAR : 4;
    UINT32  Reserved1 : 4;
  } CommonFlags;
  struct {
    UINT32  MinorVersion : 8;
    UINT32  MajorVersion : 16;
    UINT32  ReleaseVersion : 4;
    UINT32  Reserved : 4;
  } CliSpecVersion;
  UINT32  Reserved[2];
} SharedMemoryHeaderEntry;

typedef struct SharedMemoryEntry_ {
  UINT32  Signature;
  UINT32  Offset;
  UINT32  Size;
  union {
    struct {
      UINT32  AccessType    : 3;
      UINT32  ReservedType  : 5;
      UINT32  DeviceID      : 16;
      UINT32  BAR           : 4;
      UINT32  CapabilityBit : 4;
    } Flags;
    UINT32  flatFlags;
  } _u2;
} SharedMemoryEntry;

#define SHARED_MEM_MAX_ENTRY_NUMBER  10

typedef struct SharedMemoryTable_ {
  SharedMemoryHeaderEntry Header;

  ///
  /// One entry for terminator 0xDEADBEA7
  ///
  SharedMemoryEntry       Entry[SHARED_MEM_MAX_ENTRY_NUMBER + 1];
} SharedMemoryTable;

typedef struct {
  UINT32 Signature;
  UINT32 Offset;
  UINT32 Size;
  UINT32 AccessType;
} SHARED_MAILBOX_TYPE;

#define READ_MB                         0x4D
#define WRITE_MB                        0x91

#define MAILBOX_LEGACY                  0
#define MAILBOX_SHARED                  1

#define BIOS_MAILBOX                    MAILBOX_SHARED // Shared Mailbox by default for regular BIOS.
#define USE_HARDCODED_MMIO_ADRESSES     0
#define BIOS_API_LOCATION               0xF2000

#define READ_MAILBOX(Offset, Size, BufferAddr, MailboxAddress, PcieAddr)   ReadWriteMB( Offset, Size, BufferAddr, MailboxAddress, PcieAddr, READ_MB )
#define WRITE_MAILBOX(Offset, Size, BufferAddr, MailboxAddress, PcieAddr)  ReadWriteMB( Offset, Size, BufferAddr, MailboxAddress, PcieAddr, WRITE_MB )

// header signature
#define SHARED_MB_BIOS_SIG              0xBA5EBA11

// for Legacy mailbox KNOBS area
#define LEG_MAILBOX_SIG                 0x5A7ECAFE
#define LEG_MAILBOX_OFFSET              0x100
#define LEG_MAILBOX_SIZE                0x3F00

// CLI Request block area
#define CLI_REQ_SIG                     0xCA11AB1E
#define CLI_REQ_BUFFER_SIZE             0x100200
#define CLI_REQ_BUFFER_OFFSET           LEG_MAILBOX_OFFSET + LEG_MAILBOX_SIZE
// CLI Response block area
#define CLI_RES_SIG                     0xCA11B0B0
#define CLI_RES_BUFFER_SIZE             0x100200
#define CLI_RES_BUFFER_OFFSET           (CLI_REQ_BUFFER_OFFSET + CLI_REQ_BUFFER_SIZE)

#define KNOB_ENTRIES_SIZE               0x20000
#define KNOB_VALUE_MAP_SIZE             0x20000
#define KNOB_PATCH_DATA_BUFF_SIZE       0x20000
#define GET_SET_TEMP_DATA_BUFF_SIZE     0x30000
#define XMLCLI_DEBUG_LOG_BUFF_SIZE      0x40000

#define SHARED_MB_LAST_SIG              0xDEADBEA7

#define SHARED_MEMORY_FLAG_MEMORY_TYPE  0
#define SHARED_MEMORY_FLAG_MMIO_TYPE    1
#define SHARED_MEMORY_FLAG_IO_TYPE      2

VOID SharedMem_InitTable (
  SharedMemoryTable *sharedMemTable,
  UINT16            DeviceID,
  UINT8             BarNumber
);

EFI_STATUS SharedMem_addEntry (
  SharedMemoryTable *sharedMemTable,
  UINT32            Signature,
  UINT32            Offset,
  UINT32            Size,
  UINT32            AccessType
);

EFI_STATUS SharedMem_getEntryBySignature (
  SharedMemoryTable *sharedMemTable,
  UINT32            Signature,
  UINT32            *offset,
  UINT32            *size
);

EFI_STATUS SharedMem_AddTable(
  SharedMemoryTable*    sharedMemTable,
  VOID                 *XmlCliCommon,
  SHARED_MAILBOX_TYPE*  sharedMailBox,
  UINT32                MailboxAddress
);

VOID ConstructSharedMB(
  VOID      *XmlCliProto,
  SHARED_MAILBOX_TYPE *mailboxTable,
  UINT8     BarNumber,
  UINT32    VenDevId,
  UINT32    MailboxAddress
);

#pragma pack(pop)
#endif // _SHARED_MEM_DIV
